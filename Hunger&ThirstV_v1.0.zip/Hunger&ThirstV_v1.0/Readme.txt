Hunger & Thirst V - GTA V Mod

This mod adds a survival element to GTA V, requiring players to manage food and drink intake to stay alive. Hunger and thirst decrease over time, with faster depletion from activities like running or swimming. If either reaches zero, the player takes damage and eventually dies. Food and drinks can be purchased from stores.

-------------------
GENERAL FEATURES
-------------------
Hunger & Thirst System:
- Hunger and thirst meters deplete over time.
- If either reaches zero, the player takes damage and dies.

Dynamic Depletion Rates:
- Morning: Normal depletion.
- Afternoon: Fastest depletion (high activity).
- Night: Slow depletion (resting period).
- Running, sprinting, and swimming increase depletion.

Hunger & Thirst UI:
- UI bars at the bottom left corner.
- Orange = Hunger, Blue = Thirst.

-------------------
INVENTORY SYSTEM
-------------------
Item Usage:
- Eat food and drink beverages to replenish meters.
- Foods: Burger, Pizza, Sandwich (restores hunger).
- Drinks: Water, Soda, Coffee (restores thirst).

Inventory Menu (LemonUI):
- Press "I" to open inventory.
- Displays all items and allows consumption.

-------------------
STORE SYSTEM
-------------------
Convenience Stores:
- Mapped across Los Santos with blips labeled "Convenience Store."
- Buy food and drinks by pressing "E."

Available Items:
- Burger - $15
- Pizza - $20
- Sandwich - $10
- Water - $5
- Soda - $8
- Coffee - $12

Purchased items are added to the inventory.

-------------------
DEATH & RECOVERY
-------------------
- Hunger & thirst reset to 100% upon death and respawn.

-------------------
FUTURE FEATURES
-------------------
- More food & beverages.
- Alcohol & energy drinks.
- Buy beverages from vending machines and street vendors.
- Rob stores for free food.

-------------------
ISSUES & BUG REPORTS
-------------------
Report bugs and issues here:
GitHub: https://github.com/gtreeeeeeeel/Hunger-ThirstV/issues

-------------------
KEY BINDINGS
-------------------
- Press "I" to open inventory.
- Press "E" to interact with stores.

-------------------
REQUIREMENTS
-------------------
Make sure you have the following before installing:
- GTA V (Latest version recommended)
- Script Hook V
- Script Hook V .NET
- LemonUI (SHVDN3) (Included in the file)

If the script does not work, install:
- .NET Framework 4.8+
- Microsoft Visual C++ Redistributable 2015-2022

-------------------
INSTALLATION
-------------------
1. Download and extract Hunger & Thirst V mod files (WinRAR or 7-Zip recommended).
2. Place "LemonUI (SHVDN3)" inside the "scripts" folder.
3. Move the following files into "scripts":
   - Hunger_ThirstV.dll
   - Hunger&ThirstV.json
   - Newtonsoft.Json
4. If the "scripts" folder does not exist, create one.

-------------------
NOTES
-------------------
- Only compatible with Story Mode.
- Controller support is not available.

-------------------
CHANGELOGS
-------------------
v1.0 - Initial Release

-------------------
FAQ
-------------------
Q1: The mod is not working. What should I do?
A1: Ensure you have the latest versions of Script Hook V, Script Hook V .NET, and LemonUI installed.
    If the issue persists, install:
    - .NET Framework 4.8+
    - Microsoft Visual C++ Redistributable 2015-2022

Q2: Can I customize hunger/thirst depletion rates?
A2: Yes! Edit "Hunger&ThirstV.json" with a text editor to modify values.

Q3: Does hunger/thirst persist after restarting GTA V?
A3: No, it resets upon restarting the game. Future updates may change this.

Q4: What happens if hunger or thirst reaches zero?
A4: The player starts taking damage and will eventually die.

Q5: Does this mod support controllers?
A5: Not yet, but future updates may add support.

Q6: Can I add custom food and drinks?
A6: Not yet, but a future update will allow customization via the config file.

Q7: Does this mod work in FiveM?
A7: No, it is designed for GTA V Story Mode only.

Q8: How can I report a bug or request a feature?
A8: Submit reports and feature requests on the GitHub Issues page.

-------------------
IMPORTANT NOTICE
-------------------
DO NOT STEAL OR REUPLOAD THIS CODE WITHOUT PERMISSION.  
This mod is the result of hard work and effort. If you want to use or modify it, please ask for permission first.  
Respect the work of mod creators.
