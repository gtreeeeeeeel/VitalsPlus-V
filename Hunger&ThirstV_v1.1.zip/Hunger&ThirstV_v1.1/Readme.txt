-------------------
<b>CHANGELOGS</b>
-------------------
<b>v1.0 - Initial Release</b>
-------------------
<b>v1.1 - Immersive Update</b>

ADDED MEDICINES
MedKit - Use to restore 50% character's health.
Bandage - Use to restore 25% character's health.

REALISTIC FOOD AND DRINK USAGE
- When character eats Burger the Hunger +30,  and Thirst -5 this is due to greasy content.
- When character drinks Soda the Hunger +5,  and Thirst +35 due to sugary content.

NEW FOODS
- Hotdog
- Taco
- Fries

NEW DRINKS
- Milk Shake 
- Iced Tea
- Energy Drink

+ ORGANIZED STORE AND INVENTORY MENU
+ ORGANIZED NOTIFICATIONS

REALISTIC EFFECTS 

VISUAL
- When a character's hunger and thirst drop to 15%, the character's vision will dim, when it drops to 5%, the character's vision will dim entirely.

CHARACTER
- Character can't sprint or even jump if the hunger and thirst drop to 15%.

Note: These effects will disappear if hunger and thirst are 16% or higher.

REALISTIC HUNGER AND THIRST DEPLETION (Can be modified in JSON file)
-------------------

<b>Hunger & Thirst V</b> 

This mod adds a survival element to GTA V, requiring players to manage food and drink intake to stay alive. Hunger and thirst decrease over time, with faster depletion from activities like running or swimming. If either reaches zero, the player takes damage and eventually dies. Food, drinks and medicines can be purchased from stores.

-------------------
<b>GENERAL FEATURES</b>
-------------------
<b>Hunger & Thirst System:</b>
- Hunger and thirst meters deplete over time.
- If either reaches zero, the player takes damage and dies.

<b>Dynamic Depletion Rates:</b>
- Morning: Normal depletion.
- Afternoon: Fastest depletion (high activity).
- Night: Slow depletion (resting period).

- Running, sprinting, and swimming increase depletion.

<b>Hunger & Thirst UI:</b>
- UI bars at the bottom left corner.
- Orange = Hunger, Blue = Thirst.

-------------------
<b>INVENTORY SYSTEM</b>
-------------------
<b>Item Usage:</b>
- Eat food and drink beverages to replenish meters.

<b>Inventory Menu (LemonUI):</b>
- Press "I" to open inventory.
- Displays all items and allows consumption.

-------------------
<b>STORE SYSTEM</b>
-------------------
<b>Convenience Stores:</b>
- Mapped across Los Santos with blips labeled "Convenience Store."
- Buy food and drinks by pressing "E."

<b>Available Items:</b>
- Burger 
- Pizza 
- Sandwich 
- Hotdog
-Taco
-Fries

- Water 
- Soda 
- Coffee 
- Milk Shake
- Iced Tea
- Energy Drink

- MedKit
- Bandage

Purchased items are added to the inventory.

-------------------
<b>DEATH & RECOVERY</b>
-------------------
- Hunger & thirst reset to 100% upon death and respawn.

-------------------
<b>FUTURE FEATURES</b>
-------------------
- More Immersive and Realistic
- More foods, drinks and medicines variations. 

-------------------
<b>ISSUES & BUG REPORTS</b>
-------------------
<b>Report bugs and issues here:</b>
<a href="https://github.com/gtreeeeeeeel/Hunger-ThirstV/issues">GitHub</a>

-------------------
<b>KEY BINDINGS</b>
-------------------
- Press "I" to open inventory.
- Press "E" to interact with stores.

-------------------
<b>REQUIREMENTS</b>
-------------------
<b>Make sure you have the following before installing:</b>
- GTA V (Latest version recommended)
- Script Hook V
- Script Hook V .NET
- LemonUI (SHVDN3) 
<b>If the script does not work, install:</b>
- .NET Framework 4.8+
- Microsoft Visual C++ Redistributable 2015-2022

-------------------
<b>INSTALLATION</b>
-------------------
1. Download and extract Hunger & Thirst V mod files.
2. Place "LemonUI (SHVDN3)" inside the "scripts" folder.
3. Move the following files into "scripts":
   - Hunger_ThirstV.dll
   - Hunger&ThirstV.json
   - Newtonsoft.Json
4. If the "scripts" folder does not exist, create one.

-------------------
<b>NOTES</b>
-------------------
- Only compatible with Story Mode.

-------------------
<b>FAQ</b>
-------------------
Q1: The mod is not working. What should I do?
A1: Ensure you have the latest versions of Script Hook V, Script Hook V .NET, and LemonUI installed.
    If the issue persists, install:
    - .NET Framework 4.8+
    - Microsoft Visual C++ Redistributable 2015-2022

Q2: Can I customize hunger/thirst depletion rates?
A2: Yes! Edit "Hunger&ThirstV.json" with a text editor to modify values.

Q3: Does hunger/thirst persist after restarting GTA V?
A3: No, it resets upon restarting the game. Future updates may change this.

Q4: What happens if hunger or thirst reaches zero?
A4: The player starts taking damage and will eventually die.

Q5: Does this mod support controllers?
A5: Not yet, but future updates may add support.

Q6: Can I add custom food and drinks?
A6: Not yet, but a future update will allow customization via the config file.

Q7: Does this mod work in FiveM?
A7: No, it is designed for GTA V Story Mode only.

Q8: How can I report a bug or request a feature?
A8: Submit reports and feature requests <a href="https://github.com/gtreeeeeeeel/Hunger-ThirstV/issues">here.</a>

-------------------
IMPORTANT NOTICE
-------------------
DO NOT STEAL OR REUPLOAD THIS CODE WITHOUT PERMISSION.  
This mod is the result of hard work and effort. If you want to use or modify it, please ask for permission first.  
Respect the work of mod creators.